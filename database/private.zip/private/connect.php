<?php

ini_set('dispalay_errors',0);

 $dbhost="localhost";
 $dbuser="root";
 $dbpass="";
 $dbname="lovifansdb";
 $dbase = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
 
 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;

 function file_upload($dbase,$files) {
        $supfiles = [["jpg","jpeg","png","svg","gif"],["mp4","mov","avi","wmv","AVCHD"],["mp3","aac","aiff","alac","m4a","dsd"],["pdf","txt","pptx","xlsx","docx"]]; 
        $ftypes = ["image","video","audio","docs"];
        $support = false;
    
        if(!empty($files["name"])) {
            $fname = $files["name"];
            $ftype = $files["type"];
            $fext = explode(".", $fname)[1];
            $stype = "";
    
            for($i = 0; $i < 4; $i++) {
                foreach($supfiles[$i] as $s) {
                    if($s == $fext) {
                        $support = true;
                        $stype = $ftypes[$i];
                        break;
                    }
                }
            }
    
            if($support && $files["size"] <= 209715200) {
                $path = "./uploads/" . $stype ."/". date("Y-m-d")."/";
                if(!is_dir($path)) mkdir($path); // Create the directory
        

                $new_fname = date("His") .".".$fext;
                $uploadedFile = $path . $new_fname ;
                
                if(move_uploaded_file($files['tmp_name'], $uploadedFile)) {
                    mysqli_query($dbase,"INSERT INTO  file  ( file_id ,  origin ,  nname ,  ftype ,  date ) VALUES (NULL, '$fname', '$new_fname', '$stype', current_timestamp())");
                    $fid = mysqli_insert_id($dbase);
                    mysqli_query($dbase,"INSERT INTO  file_connect  ( fcid ,  file_id ) VALUES (NULL, $fid)");
                    $fcid = mysqli_insert_id($dbase);
        
    
                } else {
                    echo "uploading error";
                }
            }
        }

    }

 function mailing($mail){

 
         require "$_SESSION[priv]/PHPMailer/src/Exception.php";
         require "$_SESSION[priv]/PHPMailer/src/PHPMailer.php";
         require "$_SESSION[priv]/PHPMailer/src/SMTP.php";
 
 
         $mail = new PHPMailer(true);
 
         //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
 
         $mail->isSMTP();
         $mail->SMTPAuth = true;
         $mail->Host = "smtp.mailersend.net";
         $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
         $mail->Port = 587;
         $mail->Username = "MS_ACZujt@lovifans.com";
         $mail->Password = "qZbPCsHrP9PA3o4r";
 
         $mail->isHTML(true);
 
         return $mail;

 }

 function randoms($len = 20){
         $c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
         $rnd = "";
         for($i=1;$i<=$len;$i++) $rnd.= $c[rand(0,61)];
         return $rnd;
 }
?>